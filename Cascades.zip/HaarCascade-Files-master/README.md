# HaarCascade_files
Here you can download all the HaarCascade files used for imge processing in OPENCV
